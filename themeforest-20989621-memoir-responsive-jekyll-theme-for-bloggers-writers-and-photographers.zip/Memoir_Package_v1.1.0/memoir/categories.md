---
layout: categories
permalink: /categories/
title: Categories
subtitle: all posts
header:
    image: https://source.unsplash.com/ZfiV8EgglsY.jpg
    text: light
# You don't need to edit this file, edit theme's categories layout instead if you wanna make some changes
---
