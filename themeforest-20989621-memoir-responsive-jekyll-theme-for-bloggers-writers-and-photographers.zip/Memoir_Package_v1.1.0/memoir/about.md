---
layout: about
title: William John Smith
subtitle: writer / photographer
permalink: /about/
header:
    image: https://source.unsplash.com/DMVD9RkZIwQ.jpg
    text: light
---

## The Journey So Far
Mullam mattis lacinia efficitur. Nunc porta malesuada porta. Etiam tristique vestibulum dolor at ultricies.

Ut malesuada varius tempor. Nulla non sollicitudin tortor. Morbi sit amet laoreet ipsum, vel pretium mi. Morbi varius, tellus in accumsan blandit, elit ligula eleifend velit, luctus mattis ante nulla condimentum nulla.

{% include image.html img="https://source.unsplash.com/UZtRU-lWZE4" alt="Alt for image" %}

In accumsan lacus ac neque maximus dictum. Phasellus eleifend leo id mattis bibendum. Curabitur et purus turpis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;

Valesuada varius tempor. Nulla non sollicitudin tortor. Morbi sit amet laoreet ipsum, vel pretium mi. Morbi varius, tellus in accumsan blandit, elit ligula eleifend velit, luctus mattis ante nulla condimentum nulla.
